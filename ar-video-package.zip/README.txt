AR Video Web Package
======================
Upload all files in this folder to the root of your GitHub Pages repository.

Files:
- index.html
- video.mp4

After GitHub Pages is enabled, the page will be available at:
https://hycentude89-tech.github.io/ar-video/

Important: this package provides a camera + video WebAR-style experience. True image-target tracking requires an image-tracking engine/target file; this package does not pretend to provide that tracking.
